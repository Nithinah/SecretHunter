import pandas as pd
import numpy as np
import os

def generate_ransomware_dataset(num_samples=3000):
    print("Generating synthetic Ransomware behavior dataset...")
    np.random.seed(42)
    
    # Benign Activity (Label = 0)
    # Normal user behavior: some file reads/writes, occasional renames, low registry mods.
    num_benign = num_samples // 2
    benign_data = {
        'Files_Created_Per_Sec': np.random.poisson(1, num_benign),
        'Files_Deleted_Per_Sec': np.random.poisson(0.5, num_benign),
        'Files_Renamed_Per_Sec': np.random.poisson(0.1, num_benign),
        'Files_Read_Per_Sec': np.random.randint(5, 50, num_benign),
        'Average_Entropy': np.random.uniform(3.5, 6.0, num_benign),
        'Registry_Mods_Per_Sec': np.random.poisson(2, num_benign),
        'CPU_Usage_Percent': np.random.randint(5, 40, num_benign),
        'Label': np.zeros(num_benign, dtype=int)
    }
    
    # Ransomware Activity (Label = 1)
    # Ransomware behavior: massive file reads, mass file creations/renames, high entropy (encryption), registry changes (persistence/shadow copies deletion).
    num_malware = num_samples - num_benign
    malware_data = {
        'Files_Created_Per_Sec': np.random.randint(50, 300, num_malware),
        'Files_Deleted_Per_Sec': np.random.randint(10, 100, num_malware), # Deleting originals
        'Files_Renamed_Per_Sec': np.random.randint(50, 400, num_malware), # Renaming to .encrypted
        'Files_Read_Per_Sec': np.random.randint(100, 1000, num_malware), # Reading files to encrypt
        'Average_Entropy': np.random.uniform(7.5, 7.99, num_malware), # Encrypted data has max entropy
        'Registry_Mods_Per_Sec': np.random.randint(20, 150, num_malware), # Disabling recovery, adding run keys
        'CPU_Usage_Percent': np.random.randint(70, 100, num_malware), # Encryption is CPU intensive
        'Label': np.ones(num_malware, dtype=int)
    }
    
    # Combine and shuffle
    df_benign = pd.DataFrame(benign_data)
    df_malware = pd.DataFrame(malware_data)
    
    df = pd.concat([df_benign, df_malware], ignore_index=True)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    # Save to CSV
    os.makedirs(os.path.dirname(os.path.abspath(__file__)), exist_ok=True)
    dataset_path = 'ransomware_behavior_dataset.csv'
    df.to_csv(dataset_path, index=False)
    print(f"Dataset saved to {dataset_path} with {len(df)} samples.")

if __name__ == "__main__":
    generate_ransomware_dataset()
