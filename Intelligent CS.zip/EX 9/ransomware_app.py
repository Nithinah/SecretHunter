import gradio as gr
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(DATA_DIR, "ransomware_behavior_dataset.csv")

if not os.path.exists(DATA_PATH):
    raise Exception(f"Dataset not found at {DATA_PATH}. Please run data_generator.py first.")

# Load Dataset
print("Loading dataset and training models in the backend...")
df = pd.read_csv(DATA_PATH)
features = ['Files_Created_Per_Sec', 'Files_Deleted_Per_Sec', 'Files_Renamed_Per_Sec', 
            'Files_Read_Per_Sec', 'Average_Entropy', 'Registry_Mods_Per_Sec', 'CPU_Usage_Percent']
X = df[features]
y = df['Label']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Models
models = {
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=5),
    "Neural Network (MLP)": MLPClassifier(hidden_layer_sizes=(50,), max_iter=500, random_state=42)
}

results = []
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    results.append({
        "Model": name,
        "Accuracy": round(accuracy_score(y_test, y_pred), 4),
        "Precision": round(precision_score(y_test, y_pred), 4),
        "Recall": round(recall_score(y_test, y_pred), 4),
        "F1-Score": round(f1_score(y_test, y_pred), 4)
    })

results_df = pd.DataFrame(results)
print("Training Complete. Models evaluated.")

# Use Random Forest as the primary model for live inference
best_model = models["Random Forest"]

def predict_ransomware(created, deleted, renamed, read, entropy, reg_mods, cpu):
    input_data = pd.DataFrame([[
        created, deleted, renamed, read, entropy, reg_mods, cpu
    ]], columns=features)
    
    prediction = best_model.predict(input_data)[0]
    confidence = best_model.predict_proba(input_data)[0]
    
    if prediction == 1:
        return f"🚨 RANSOMWARE ACTIVITY DETECTED 🚨\n\nConfidence: {confidence[1]*100:.2f}%\nIsolate this machine immediately. Behavior matches file encryption and mass modification."
    else:
        return f"✅ NORMAL SYSTEM BEHAVIOR ✅\n\nConfidence: {confidence[0]*100:.2f}%\nSystem operations are within expected thresholds."


with gr.Blocks() as app:
    gr.Markdown("# 🔒 Ransomware Behavior Detector (EX 9)")
    gr.Markdown("Monitor system activities (file operations, registry modifications, CPU) to detect active ransomware infections using Machine Learning.")
    
    with gr.Tabs():
        with gr.TabItem("Live Telemetry Analysis"):
            with gr.Row():
                with gr.Column():
                    gr.Markdown("### 📁 File System Operations (Per Second)")
                    created = gr.Slider(0, 1000, value=2, label="Files Created / Sec", step=1)
                    deleted = gr.Slider(0, 1000, value=1, label="Files Deleted / Sec", step=1)
                    renamed = gr.Slider(0, 1000, value=0, label="Files Renamed / Sec", step=1)
                    read = gr.Slider(0, 2000, value=15, label="Files Read / Sec", step=1)
                    entropy = gr.Slider(1.0, 8.0, value=4.5, label="Average File Entropy (Data Randomness)", step=0.1)
                    
                    gr.Markdown("### 💻 System & OS Metrics")
                    reg_mods = gr.Slider(0, 500, value=1, label="Registry Modifications / Sec", step=1)
                    cpu = gr.Slider(0, 100, value=15, label="CPU Usage (%)", step=1)
                    
                    btn_predict = gr.Button("🔍 Analyze Telemetry", variant="primary")
                    
                with gr.Column():
                    gr.Markdown("### 🛡️ Real-Time Alerts")
                    txt_result = gr.Textbox(label="Detection Status", interactive=False, lines=4)
                    
            btn_predict.click(
                fn=predict_ransomware,
                inputs=[created, deleted, renamed, read, entropy, reg_mods, cpu],
                outputs=[txt_result]
            )
            
        with gr.TabItem("Model Evaluation"):
            gr.Markdown("### 📊 Backend Model Effectiveness")
            gr.Markdown("Comparison of classifiers trained on the generated ransomware behavior dataset.")
            gr.Dataframe(results_df)
            
            gr.Markdown("### 📁 Dataset Sample (Raw Telemetry Data)")
            gr.Dataframe(df.head(15))

if __name__ == "__main__":
    app.launch(server_name="127.0.0.1", server_port=7865, inbrowser=True, theme=gr.themes.Soft())
