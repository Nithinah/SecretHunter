import pandas as pd
import numpy as np
import os

def generate_pe_dataset(num_samples=2000):
    print("Generating synthetic PE features dataset...")
    np.random.seed(42)
    
    # Generate Benign samples (Label = 0)
    # Benign usually have normal sizes, common DLL characteristics, fewer sections
    num_benign = num_samples // 2
    benign_data = {
        'MajorLinkerVersion': np.random.randint(8, 15, num_benign),
        'SizeOfCode': np.random.randint(10240, 1024000, num_benign),
        'SizeOfInitializedData': np.random.randint(5120, 512000, num_benign),
        'NumberOfSections': np.random.randint(3, 7, num_benign),
        'DllCharacteristics': np.random.choice([33088, 32768, 16384], num_benign), # Typical benign flags
        'Entropy': np.random.uniform(4.0, 6.0, num_benign), # Lower entropy
        'Label': np.zeros(num_benign, dtype=int)
    }
    
    # Generate Malicious samples (Label = 1)
    # Malware often has high entropy (packed), unusual section counts, different linker versions
    num_malware = num_samples - num_benign
    malware_data = {
        'MajorLinkerVersion': np.random.randint(2, 10, num_malware),
        'SizeOfCode': np.random.randint(1024, 51200, num_malware), # Sometimes smaller if packed
        'SizeOfInitializedData': np.random.randint(0, 10240, num_malware),
        'NumberOfSections': np.random.randint(1, 10, num_malware),
        'DllCharacteristics': np.random.choice([0, 32768, 33088], num_malware),
        'Entropy': np.random.uniform(6.5, 7.9, num_malware), # Higher entropy due to packing/encryption
        'Label': np.ones(num_malware, dtype=int)
    }
    
    # Combine and shuffle
    df_benign = pd.DataFrame(benign_data)
    df_malware = pd.DataFrame(malware_data)
    
    df = pd.concat([df_benign, df_malware], ignore_index=True)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    # Save to CSV
    os.makedirs(os.path.dirname(os.path.abspath(__file__)), exist_ok=True)
    dataset_path = 'pe_features_dataset.csv'
    df.to_csv(dataset_path, index=False)
    print(f"Dataset saved to {dataset_path} with {len(df)} samples.")

if __name__ == "__main__":
    generate_pe_dataset()
