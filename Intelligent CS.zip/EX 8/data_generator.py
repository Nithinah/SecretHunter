import pandas as pd
import numpy as np
import os

def generate_pdf_dataset(num_samples=2500):
    print("Generating synthetic PDF features dataset...")
    np.random.seed(42)
    
    # Benign PDFs (Label = 0)
    # Benign PDFs typically have very few or no JS, Launch, or embedded scripts.
    num_benign = num_samples // 2
    benign_data = {
        'Total_Pages': np.random.randint(1, 100, num_benign),
        'Total_Objects': np.random.randint(10, 500, num_benign),
        'Total_Streams': np.random.randint(2, 100, num_benign),
        'Count_JavaScript': np.random.poisson(0.01, num_benign), # Extremely rare
        'Count_JS': np.random.poisson(0.01, num_benign),
        'Count_OpenAction': np.random.poisson(0.05, num_benign), # Sometimes used benignly for zoom
        'Count_RichMedia': np.random.poisson(0.01, num_benign),
        'Count_Launch': np.zeros(num_benign, dtype=int), # Almost never in benign
        'Label': np.zeros(num_benign, dtype=int)
    }
    
    # Malicious PDFs (Label = 1)
    # Malicious PDFs often exploit JavaScript, JS, OpenAction, and Launch commands.
    num_malware = num_samples - num_benign
    malware_data = {
        'Total_Pages': np.random.randint(1, 10, num_malware), # Often single-page phishing/exploit docs
        'Total_Objects': np.random.randint(5, 200, num_malware),
        'Total_Streams': np.random.randint(1, 50, num_malware),
        'Count_JavaScript': np.random.poisson(2.5, num_malware), # Much more common
        'Count_JS': np.random.poisson(2.0, num_malware),
        'Count_OpenAction': np.random.poisson(1.5, num_malware), # Used to execute code on open
        'Count_RichMedia': np.random.poisson(0.5, num_malware),
        'Count_Launch': np.random.poisson(0.8, num_malware), # Used to launch local executables
        'Label': np.ones(num_malware, dtype=int)
    }
    
    # Combine and shuffle
    df_benign = pd.DataFrame(benign_data)
    df_malware = pd.DataFrame(malware_data)
    
    df = pd.concat([df_benign, df_malware], ignore_index=True)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    # Save to CSV
    os.makedirs(os.path.dirname(os.path.abspath(__file__)), exist_ok=True)
    dataset_path = 'pdf_malware_dataset.csv'
    df.to_csv(dataset_path, index=False)
    print(f"Dataset saved to {dataset_path} with {len(df)} samples.")

if __name__ == "__main__":
    generate_pdf_dataset()
